x = window.x;
tests.state = {
	basic : (t)=>{
		throw 'plz implement'
	},

}