x = window.x;
tests.list = {
	basic : (t)=>{
		throw 'plz implement'
	},

}