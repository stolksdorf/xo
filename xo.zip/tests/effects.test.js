x = window.x;
tests.effects = {
	basic : (t)=>{
		throw 'plz implement'
	},

}